﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace sFTPFileCheckingService
{
    public class DBClass
    {
        private string _ConnectionString = ConfigurationManager.ConnectionStrings["sftpDB"].ConnectionString;
        OleDbConnection _Conn;
        OleDbCommand _Cmd;
        OleDbDataAdapter _dapt;
        string qry = string.Empty;

        public virtual DataTable GetHostList()
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select * from tblsFTPHost where Status='A' order by ID", _Conn))
                    {
                        _dapt = new OleDbDataAdapter(_Cmd);
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return null;
        }

        public virtual string DecryptPassword(string encryptedpassword)
        {
            byte[] data = Convert.FromBase64String(encryptedpassword);
            string decryptedpasswrod = System.Text.ASCIIEncoding.ASCII.GetString(data);
            return decryptedpasswrod;
        }

        public virtual DataTable GetHostFilepath(string hostId)
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select * from tblsFTPFilepath where SFTPHostNo =" + hostId + " and status ='A'", _Conn))
                    {
                        _dapt = new OleDbDataAdapter(_Cmd);
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            { return null; }
            return null;
        }

        public virtual bool Savelog(string hostId, string fileName, string fileDate, Int32 CustomerId)
        {
            bool flg = false;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Insert Into tblsFTPfilelog (fileName,fileDate,hostId,CustomerId,EmailAcknowledge,CustomerAcknowledgement) Values ('" + fileName + "','" + fileDate + "'," + hostId + "," + CustomerId + ",'N','N')", _Conn))
                    {
                        qry = _Cmd.CommandText;
                        _Cmd.ExecuteNonQuery();
                        flg = true;
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile(qry);
                return flg;
            }
            return flg;
        }

        public virtual bool Checkinglogfile(string hostid, string fileName, string fileDate)
        {
            bool flg = false;
            int _cnt = 0;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select count(*) from tblsFTPfilelog where hostId =" + hostid + " and fileName ='" + fileName + "' and fileDate ='" + fileDate + "'", _Conn))
                    {
                        _cnt = Convert.ToInt32(_Cmd.ExecuteScalar());
                        qry = _Cmd.CommandText;
                        if (_cnt > 0)
                        { flg = true; }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile(qry);
                return flg;
            }
            return flg;
        }

        public virtual DataTable GetsFTPlogFiles(Int32 hostid, Int32 customerid)
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    //Select l.filename,l.filedate,l.hostid,h.hostname,f.customername,f.SFTPfilepath,f.Id from ((tblsftpfilelog as l inner join tblsftphost as h on l.hostid=h.id) Inner join tblsftpfilepath as f on l.hostid=f.SFTPHostNo) where EmailAcknowledge ='N' order by f.id,l.hostid,l.customername
                    using (_Cmd = new OleDbCommand("Select l.filename,l.filedate,l.hostid,f.customername,f.SFTPfilepath,f.Id,l.CustomerId,h.hostname from ((tblsftpfilelog as l Inner join tblsftpfilepath as f on l.CustomerId = f.id) Inner Join tblsftphost as h on f.SFTPHostNo = h.id )  where l.EmailAcknowledge ='N' and hostId =" + hostid + " and CustomerId=" + customerid + " order by l.hostid, f.id ", _Conn))
                    {
                        _dapt = new OleDbDataAdapter(_Cmd);
                        //qry = _Cmd.CommandText;
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            //sFTPFileCheckingService.WriteToFile("Datatable qry :" + _Cmd.CommandText);
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile(qry);
                sFTPFileCheckingService.WriteToFile(ex.Message);
            }
            return null;
        }

        public virtual bool EmailAcknowledge(Int32 hostId, string fileName, string fileDate, Int32 CustomerId)
        {
            bool flg = false;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Update tblsftpfilelog set EmailAcknowledge ='Y' where hostId=" + hostId + " and  filename='" + fileName + "' and fileDate ='" + fileDate + "' and CustomerId =" + CustomerId + " ", _Conn))
                    {
                        _Cmd.ExecuteNonQuery();
                        qry = _Cmd.CommandText;
                        //sFTPFileCheckingService.WriteToFile("Email Ack: " + _Cmd.CommandText);
                        flg = true;
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return flg;
                sFTPFileCheckingService.WriteToFile(qry);
                sFTPFileCheckingService.WriteToFile(ex.Message);
            }
            return flg;
        }

        public virtual bool CustomerAcknowledgement(Int32 hostId, string fileName, string fileDate, Int32 CustomerId)
        {
            bool flg = false;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Update tblsftpfilelog set CustomerAcknowledgement ='Y' where hostId=" + hostId + " and  filename='" + fileName + "' and DateValue(fileDate) = DateValue('" + fileDate + "') and CustomerId =" + CustomerId + " ", _Conn))
                    {
                        qry = _Cmd.CommandText;
                        _Cmd.ExecuteNonQuery();
                        //sFTPFileCheckingService.WriteToFile("Email Ack: " + _Cmd.CommandText);
                        flg = true;
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return flg;
                sFTPFileCheckingService.WriteToFile(qry);
                sFTPFileCheckingService.WriteToFile(ex.Message);
            }
            return flg;
        }

        public virtual DataTable GetAcknowledgedfiles(Int32 hostId, string fileDate, Int32 CustomerId)
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    // qry = "Select * from tblsFTPfilelog where hostId =" + hostId + " and DateValue(fileDate) = DateValue('" + fileDate + "') and CustomerId =" + CustomerId + " and EmailAcknowledge ='Y'";
                    //sFTPFileCheckingService.WriteToFile(qry);
                    using (_Cmd = new OleDbCommand("Select * from tblsFTPfilelog where hostId =" + hostId + " and DateValue(fileDate) = DateValue('" + fileDate + "') and CustomerId =" + CustomerId + " and EmailAcknowledge ='Y' and CustomerAcknowledgement ='N'", _Conn))
                    {
                        _dapt = new OleDbDataAdapter(_Cmd);
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            { return null; }
            return null;
        }

        public virtual DataTable CheckingfileReceived(Int32 hostId, string fileDate, Int32 CustomerId)
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    // qry = "Select * from tblsFTPfilelog where hostId =" + hostId + " and DateValue(fileDate) = DateValue('" + fileDate + "') and CustomerId =" + CustomerId + " and EmailAcknowledge ='Y'";
                    //sFTPFileCheckingService.WriteToFile(qry);
                    using (_Cmd = new OleDbCommand("Select * from tblsFTPfilelog where hostId =" + hostId + " and DateValue(fileDate) = DateValue('" + fileDate + "') and CustomerId =" + CustomerId + " and EmailAcknowledge ='Y' and CustomerAcknowledgement ='Y'", _Conn))
                    {
                        //sFTPFileCheckingService.WriteToFile(_Cmd.CommandText);
                        _dapt = new OleDbDataAdapter(_Cmd);
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            { return null; }
            return null;
        }

        public virtual bool InsertFilenotreceivedAcknowledgement(Int32 hostId, string fileDate, Int32 CustomerId)
        {
            bool flg = false;
            object count = 0;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select count(*) from tblfilerecvAckfailed  where hostid=" + hostId + " and CustomerId=" + CustomerId + " and DateValue(processdate)=DateValue('" + fileDate + "')", _Conn))
                    {
                        qry = _Cmd.CommandText;
                        count = _Cmd.ExecuteScalar();
                        //sFTPFileCheckingService.WriteToFile(qry);
                        flg = true;
                    }
                    _Conn.Close();
                }
                flg = false;
                //  sFTPFileCheckingService.WriteToFile(count.ToString());
                if (Convert.ToInt32(count) == 0)
                {
                    using (_Conn = new OleDbConnection(_ConnectionString))
                    {
                        _Conn.Open();
                        using (_Cmd = new OleDbCommand("Insert Into tblfilerecvAckfailed (hostid,CustomerId,processdate,mailsendACK) Values (" + hostId + "," + CustomerId + ",'" + fileDate + "','N')", _Conn))
                        {
                            qry = _Cmd.CommandText;
                            _Cmd.ExecuteNonQuery();
                            //sFTPFileCheckingService.WriteToFile(qry);
                            flg = true;
                        }
                        _Conn.Close();
                    }
                }
                flg = false;
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select count(*) from tblfilerecvAckfailed  where hostid=" + hostId + " and CustomerId=" + CustomerId + " and DateValue(processdate)=DateValue('" + fileDate + "') and mailsendACK ='N'", _Conn))
                    {
                        qry = _Cmd.CommandText;
                        count = _Cmd.ExecuteScalar();
                        if (Convert.ToInt32(count) > 0)
                        {
                            //sFTPFileCheckingService.WriteToFile(qry);
                            flg = true;
                            return flg;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile(qry);
                flg = false;
                return flg;
            }
            return flg;
        }

        public virtual bool UpdateFilenotreceivedAcknowledgement(Int32 hostId, string fileDate, Int32 CustomerId)
        {
            bool flg = false;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Update tblfilerecvAckfailed set mailsendACK ='Y' where hostid=" + hostId + " and CustomerId=" + CustomerId + " and DateValue(processdate)=DateValue('" + fileDate + "')", _Conn))
                    {
                        qry = _Cmd.CommandText;
                        _Cmd.ExecuteNonQuery();
                        flg = true;
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile(qry);
                return flg;
            }
            return flg;
        }

        public virtual bool DataPurge(string currentDate)
        {
            bool flg = false;
            Int32 cnt = 0;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select count(*) as cnt from tblsftpfilelog where DateValue(filedate) = DateValue('" + currentDate + "') AND  EmailAcknowledge ='Y'", _Conn))
                    {
                        cnt = Convert.ToInt32(_Cmd.ExecuteScalar());
                        sFTPFileCheckingService.WriteToFile("Data purge records count [" + cnt + "]");
                    }
                    _Conn.Close();
                }

                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Delete from tblsftpfilelog where DateValue(filedate) = DateValue('" + currentDate + "') AND  EmailAcknowledge ='Y' ", _Conn))
                    {
                        _Cmd.ExecuteNonQuery();
                        sFTPFileCheckingService.WriteToFile("Data purge Query [" + _Cmd.CommandText + "]");
                        sFTPFileCheckingService.WriteToFile("Data purge executed successfully on [" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + "]");
                        flg = true;
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile("Data purge Query on [Delete from tblsftpfilelog where DateValue(filedate) = DateValue('" + currentDate + "') AND  EmailAcknowledge ='Y']");
                sFTPFileCheckingService.WriteToFile("Data purge failed on [" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt") + "] Error : [" + ex.Message + "]");
                return flg;
            }
            return flg;
        }

        public virtual DataTable GetEmailIds(Int32 Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select top 1 * from tblEmailgrp where FilepathId =" + Id + " Order by ID desc", _Conn))
                    {
                        _dapt = new OleDbDataAdapter(_Cmd);
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return null;
        }

        public virtual DataTable GetAutoreplyEmailIds(Int32 Id)
        {
            DataTable dt = new DataTable();
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select top 1 * from tblAutoreplyemailgrp where FilepathId =" + Id + " Order by ID desc", _Conn))
                    {
                        _dapt = new OleDbDataAdapter(_Cmd);
                        _dapt.Fill(dt);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return null;
        }

        public virtual Int32 GetSalesId(string sFtpfilePath)
        {
            Int32 SalesId = 0;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select SalesId from tblsFTPFilepath where SFTPfilepath ='" + sFtpfilePath + "'", _Conn))
                    {
                        SalesId = Convert.ToInt32(_Cmd.ExecuteScalar());
                        if (SalesId > 0)
                        {
                            return SalesId;
                        }
                    }
                    _Conn.Close();
                }

            }
            catch (Exception ex)
            {
                return SalesId;
            }
            return SalesId;
        }

        public virtual Int32 RecordCount(Int32 Id)
        {
            Int32 Cnt = 0;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select count(*) from tblsftpfilelog  as s Inner join tblsftpfilepath as p on s.customerid = p.id where s.EmailAcknowledge ='N' and s.CustomerId =" + Id + "", _Conn))
                    {
                        Cnt = Convert.ToInt32(_Cmd.ExecuteScalar());
                        // sFTPFileCheckingService.WriteToFile("return record count:" + Cnt.ToString());
                        if (Cnt >= 0)
                        {
                            return Cnt;
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
            return 0;
        }

        public virtual string GetOmittedDirectory(Int32 Id)
        {
            object omittedDirectory = string.Empty;
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    using (_Cmd = new OleDbCommand("Select OmittedDirectory from tblsFTPFilepath where ID =" + Id + " and Status ='A'", _Conn))
                    {
                        omittedDirectory = _Cmd.ExecuteScalar();
                        // sFTPFileCheckingService.WriteToFile("return record count:" + Cnt.ToString());
                        if (omittedDirectory != string.Empty)
                        {
                            return omittedDirectory.ToString();
                        }
                    }
                    _Conn.Close();
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
            return string.Empty;
        }
        public virtual bool CreateColumn(string colname)
        {
            try
            {
                using (_Conn = new OleDbConnection(_ConnectionString))
                {
                    _Conn.Open();
                    bool exist = true;
                    using (_Cmd = new OleDbCommand("Select top 1 " + colname + " from tblsFTPFilepath", _Conn))
                    {
                        try
                        {
                            var x = _Cmd.ExecuteScalar();
                        }
                        catch (Exception ex)
                        {
                            exist = false;
                        }
                        if (!exist)
                        {
                            _Cmd = new OleDbCommand("ALTER TABLE tblsFTPFilepath ADD COLUMN " + colname + " TEXT(255)", _Conn);
                            _Cmd.ExecuteNonQuery();
                        }
                    }
                    _Conn.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
