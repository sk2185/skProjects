﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;


namespace sFTPFileCheckingService
{
    class DataEmail
    {
        string server;
        string email;
        string displayname;
        string user;
        string password;

        public DataEmail()
        {
            server = "smtp.office365.com";
           user = "username.office.com";
           password = "password1124";
           email = "username.office.com";
            displayname = "Data Report";
        }

        public bool SendMail(string fromadd, string toadd, string bccadd, string subject, string emailbody)
        {
            try
            {
                SmtpClient smtp = new SmtpClient(server, 587);
                //SmtpClient smtp = new SmtpClient(server, 25);

                smtp.Credentials = new System.Net.NetworkCredential(user, password);
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.EnableSsl = true;

                MailMessage msg = new MailMessage();
                msg.From = new MailAddress(email, displayname);

                if (toadd != "")
                    msg.To.Add(toadd);

                if (bccadd != "")
                    msg.Bcc.Add(bccadd);
                msg.Subject = subject;
                msg.Body = emailbody;
                msg.IsBodyHtml = true;

                //smtp.SendMailAsync(msg); //SendMailAsync
                smtp.Send(msg);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
