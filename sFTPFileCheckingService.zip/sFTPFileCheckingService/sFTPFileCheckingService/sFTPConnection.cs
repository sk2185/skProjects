﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Renci.SshNet;
using Renci.SshNet.Sftp;
using System.Net.Sockets;
using System.Data;
using System.Configuration;
using System.Globalization;

namespace sFTPFileCheckingService
{

    public class sFTPConnection
    {
        DBClass db = new DBClass();
        SftpClient _sftp;
        string mailBodytext;
        string mailbody;
        string cutofftime;
        //bool flg = false;
        string sftpData = string.Empty;

        public bool sFTPList()
        {
            bool sftpFlg = false;
            try
            {
                db.CreateColumn("OmittedDirectory");
                DataTable dt = new DataTable();
                dt = db.GetHostList();
                if (dt != null && dt.Rows.Count > 0)
                {
                    sftpFlg = sFTPConnect(dt);
                    if (sftpFlg)
                    {
                        return sftpFlg;
                    }
                }
            }
            catch (Exception ex)
            {
                sFTPFileCheckingService.WriteToFile("[Error] Error in sftp connection [Error Message : " + ex.Message + "] on " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt"));
                return false;
            }
            return false;
        }

        public bool sFTPConnect(DataTable dt)
        {
            string host = string.Empty;
            string username = string.Empty;
            string password = string.Empty;
            string hostName = string.Empty;
            int port = 0;
            string hostid = string.Empty;
            DataTable dtsftpfilepath;
            string _todaydate = DateTime.Now.ToString("ddMMyyyy");
            string sftpfilepath = string.Empty;
            try
            {
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow rw in dt.Rows)
                    {
                        host = rw["Host"].ToString();
                        username = rw["UserName"].ToString();
                        password = rw["UPassword"].ToString();
                        port = int.Parse(rw["Port"].ToString());
                        hostid = rw["ID"].ToString();
                        hostName = rw["HostName"].ToString();
                        string customername;
                        using (_sftp = new SftpClient(host, port, username, password))
                        {
                            try
                            {
                                _sftp.Connect();
                                if (_sftp.IsConnected)
                                {
                                    sFTPFileCheckingService.WriteToFile("sFTP connected Successfully in Host [Host Name: " + hostName + "] ");

                                    Int32 CustomerId;
                                    bool autoreply;

                                    dtsftpfilepath = db.GetHostFilepath(hostid);
                                    if (dtsftpfilepath != null && dtsftpfilepath.Rows.Count > 0)
                                    {
                                        foreach (DataRow rws in dtsftpfilepath.Rows)
                                        {
                                            sftpfilepath = rws["SFTPfilepath"].ToString();
                                            CustomerId = Convert.ToInt32(rws["Id"]);
                                            customername = rws["CustomerName"].ToString();
                                            // ************************** Acknowledgement to Customer Start **************************
                                            sFTPFileCheckingService.WriteToFile("sFTP connected Successfully in sFTP file path [sFTP File Path : " + sftpfilepath + "] ");
                                            autoreply = rws["Autoreply"].ToString() == "Y" ? true : false;
                                            cutofftime = rws["Cutofftime"].ToString();
                                            RecursivelyFilechecking(sftpfilepath, _todaydate, hostid, true, hostName, CustomerId);
                                            if (cutofftime != string.Empty)
                                            {
                                                AcknowledgementEmailSend(hostid, autoreply, CustomerId, customername);
                                            }


                                            // ************************** Acknowledgement to Customer End **************************
                                        }

                                    }
                                }
                                _sftp.Disconnect();
                                sftpfilepath = string.Empty;
                            }
                            catch (Exception ex)
                            {
                                _sftp.Disconnect();
                                sFTPFileCheckingService.WriteToFile("[Error] Error in sftp connection [Host Name: " + hostName + "]");
                                sFTPFileCheckingService.WriteToFile("[Error] Error in sftp connection [sFTP File Path : " + sftpfilepath + "]" + " Error message : " + ex.Message + " on " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt"));
                            }
                        }
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                //_sftp.Dispose();
                sFTPFileCheckingService.WriteToFile("[Error] Error in sftp connection [Host Name: " + hostName + "]");
                sFTPFileCheckingService.WriteToFile("[Error] Error in sftp connection [sFTP File Path : " + sftpfilepath + "]" + " Error message : " + ex.Message + " on " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt"));
                // return false;
            }


            return false;
        }

        #region  AcknowledgementEmailSend
        // ************************ Acknowledgement to Customer Start ************************
        private void AcknowledgementEmailSend(string hostid, bool autoreply, Int32 filepathId, string customername)
        {
            //sFTPFileCheckingService.WriteToFile("autoreply : " + autoreply);
            //sFTPFileCheckingService.WriteToFile("datetime : " + DateTime.Now.ToString("hh:mmtt"));
            //sFTPFileCheckingService.WriteToFile("cutofftime : " + cutofftime);
            //sFTPFileCheckingService.WriteToFile("cutofftime with formatted : " + Convert.ToInt32(cutofftime.Substring(0, 5).Replace(":", "")));

            string JobMailBody = string.Empty;
            string toadd = string.Empty;
            bool flg;
            string fromMail = ConfigurationManager.AppSettings["fromMail"].ToString();
            string fileDate = DateTime.Now.ToString("dd/MM/yyyy hh:mm tt");
            bool truetime = false;
            if (cutofftime != "0")
            {
                //sFTPFileCheckingService.WriteToFile("before Converted cutofftime :" + cutofftime);

                Int32 currenttimehr = Convert.ToInt32(DateTime.Now.ToString("hh"));
                Int32 currenttimeminute = Convert.ToInt32(DateTime.Now.ToString("mm"));
                string currenttimeampm = DateTime.Now.ToString("tt");
                DateTime comparecutofftime = DateTime.ParseExact(cutofftime.Substring(0, 5) + ":00", "HH:mm:ss", CultureInfo.InvariantCulture);
                // DateTime comparecutofftime = DateTime.ParseExact(cutofftime, "HH:mm:sstt", CultureInfo.InvariantCulture);
                Int32 cutofftimehr = Convert.ToInt32(comparecutofftime.ToString("hh"));
                Int32 cutofftimeminute = Convert.ToInt32(comparecutofftime.ToString("mm"));
                string cutofftimeampm = cutofftime.Substring(5, 2);

                comparecutofftime = Convert.ToDateTime(comparecutofftime.ToString().Replace("AM", cutofftimeampm));

                //sFTPFileCheckingService.WriteToFile("cutofftime without change:" + comparecutofftime);
                //sFTPFileCheckingService.WriteToFile("currenttime hr :" + currenttimehr.ToString() + " minute : " + currenttimeminute.ToString() + " AM/PM : " + currenttimeampm);
                //sFTPFileCheckingService.WriteToFile("cutofftime hr :" + cutofftimehr.ToString() + " minute : " + cutofftimeminute.ToString() + " AM/PM : " + cutofftimeampm);
                //sFTPFileCheckingService.WriteToFile("Time difference  Hours:" + DateTime.Now.Subtract(comparecutofftime).Hours + " Minutes : " + DateTime.Now.Subtract(comparecutofftime).Minutes);

                if (DateTime.Now.Subtract(comparecutofftime).Hours >= 0 && DateTime.Now.Subtract(comparecutofftime).Minutes >= 0 && currenttimeampm == cutofftimeampm)
                {
                    truetime = true;
                    //sFTPFileCheckingService.WriteToFile("Time difference after compared Hours:" + DateTime.Now.Subtract(comparecutofftime).Hours + " Minutes : " + DateTime.Now.Subtract(comparecutofftime).Minutes);
                }

                //if (currenttimehr.ToString().Length == cutofftimehr.ToString().Length)
                //{
                //    sFTPFileCheckingService.WriteToFile("currenttime hr :" + currenttimehr.ToString() + " minute : " + currenttimeminute.ToString() + " AM/PM : " + currenttimeampm);
                //    sFTPFileCheckingService.WriteToFile("cutofftime hr :" + cutofftimehr.ToString() + " minute : " + cutofftimeminute.ToString() + " AM/PM : " + cutofftimeampm);
                //    if (currenttimehr > cutofftimehr && currenttimeampm != cutofftimeampm)
                //    { truetime = false; }
                //    else if (currenttimehr >= cutofftimehr && currenttimeampm == cutofftimeampm)
                //    {
                //        if (currenttimeminute >= cutofftimeminute)
                //        {
                //            truetime = true;
                //        }
                //        else
                //        {
                //            truetime = false;
                //        }
                //    }
                //    else if (currenttimehr < cutofftimehr && currenttimeampm == cutofftimeampm)
                //    {
                //        truetime = true;
                //    }
                //}
                //if (DateTime.Now.TimeOfDay > comparecutoff.TimeOfDay)
                //{
                //    sFTPFileCheckingService.WriteToFile("Cutofftime greather than  currentime : " + DateTime.Now.TimeOfDay + " cutofftime : " + comparecutoff.TimeOfDay);
                //}
                //else
                //{
                //    sFTPFileCheckingService.WriteToFile("Cutofftime less or equal than  currentime : " + DateTime.Now.TimeOfDay + " cutofftime : " + comparecutoff.TimeOfDay);
                //}
            }

            if (autoreply && truetime) //&& Convert.ToInt32(DateTime.Now.ToString("hhmm")) >= Convert.ToInt32(cutofftime.Substring(0, 5).Replace(":", "")))
            {
                //sFTPFileCheckingService.WriteToFile("truetime status : " + truetime);
                //sFTPFileCheckingService.WriteToFile("cutofftime : " + Convert.ToInt32(cutofftime.Substring(0, 5).Replace(":", "")));

                DataTable dtmail = db.GetAutoreplyEmailIds(filepathId);
                if (dtmail != null && dtmail.Rows.Count > 0)
                {

                    foreach (DataRow rw in dtmail.Rows)
                        toadd += rw["Emailgrp"].ToString();
                    toadd = toadd.Substring(0, toadd.Length);

                }

                //sFTPFileCheckingService.WriteToFile("hostid : " + hostid + " filedate :" + fileDate + " Customerid : " + filepathId);

                DataTable dtacknowledgedfiles = db.GetAcknowledgedfiles(Convert.ToInt32(hostid), fileDate, filepathId);
                string htmlbody = string.Empty;
                string bottom = string.Empty;
                string htmlcontent = string.Empty;

                if (dtacknowledgedfiles != null && dtacknowledgedfiles.Rows.Count > 0)  // Checking whether data received or not.
                {

                    for (int j = 0; j <= dtacknowledgedfiles.Rows.Count - 1; j++)
                    {
                        if (j == 0)
                        {
                            //sFTPFileCheckingService.WriteToFile("record count : " + (dtacknowledgedfiles.Rows.Count));
                            JobMailBody = @"<html>" +
                            "<body>" +
                            "<p>Dear Team,</p>" +
                            "<p>The below embossing file has been received to USP SFTP Server on Dated: <b>" + dtacknowledgedfiles.Rows[j]["fileDate"].ToString() + "</b>.</p>" +
                            "<p><b><u>File Name:-</u></b></p>";

                            if (j == 0 && j == dtacknowledgedfiles.Rows.Count - 1)
                            {
                                JobMailBody += dtacknowledgedfiles.Rows[j]["filename"].ToString() + "</p>" +
                                 "<p>Best regards,<br />" +
                            "(Automated email, please do not reply.)</p>" +
                            "</body>" +
                            "</html>";
                            }
                            else
                            {
                                JobMailBody += "<p>" + dtacknowledgedfiles.Rows[j]["filename"].ToString() + "<br/>";
                                //sFTPFileCheckingService.WriteToFile("Record : " + j + "  filename : " + dtacknowledgedfiles.Rows[j]["filename"].ToString());
                                // sFTPFileCheckingService.WriteToFile("Start Data mail content " + JobMailBody);
                            }
                        }
                        else if (j == dtacknowledgedfiles.Rows.Count - 1)
                        {
                            JobMailBody += dtacknowledgedfiles.Rows[j]["filename"].ToString() + "</p>" +
                            "<p>Best regards,<br />" +
                            "(Automated email, please do not reply.)</p>" +
                            "</body>" +
                            "</html>";

                            //sFTPFileCheckingService.WriteToFile("Record : " + j + "  filename : " + dtacknowledgedfiles.Rows[j]["filename"].ToString());
                            // sFTPFileCheckingService.WriteToFile("End Data mail content " + JobMailBody);
                        }
                        else
                        {
                            JobMailBody += dtacknowledgedfiles.Rows[j]["filename"].ToString() + "<br/>";
                            //sFTPFileCheckingService.WriteToFile("Record : " + j + "  filename : " + dtacknowledgedfiles.Rows[j]["filename"].ToString());
                            //sFTPFileCheckingService.WriteToFile("Data mail content " + JobMailBody);
                        }
                        //sFTPFileCheckingService.WriteToFile("increment value " + j);
                        //sFTPFileCheckingService.WriteToFile("Record : " + j + "  filename : " + dtacknowledgedfiles.Rows[j]["filename"].ToString());
                    }

                    DataEmail mail = new DataEmail();
                    flg = mail.SendMail(fromMail, toadd, "", "sFTP File Received Acknowledgement", JobMailBody);
                    if (flg)
                    {
                        for (int j = 0; j <= dtacknowledgedfiles.Rows.Count - 1; j++)
                        {
                            flg = db.CustomerAcknowledgement(Convert.ToInt32(hostid), dtacknowledgedfiles.Rows[j]["filename"].ToString(), fileDate, filepathId);
                        }

                        if (flg)
                        {
                            sFTPFileCheckingService.WriteToFile("Customer Acknowledgement Mail send to [" + customername + "] on " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt") + "  successfully...");
                        }
                    }
                }

                //else //data not received send mail to customer
                //{
                //    //sFTPFileCheckingService.WriteToFile("before start file received checking status : " + truetime);

                //    DataTable dtcheckingfilereceived = db.CheckingfileReceived(Convert.ToInt32(hostid), fileDate, filepathId);

                //    if (dtcheckingfilereceived == null)  // confirming data not received.
                //    {

                //        flg = db.InsertFilenotreceivedAcknowledgement(Convert.ToInt32(hostid), fileDate, filepathId);
                //        if (flg)
                //        {
                //            JobMailBody = string.Empty;
                //            JobMailBody = @"<html>" +
                //              "<body>" +
                //              "<p>Dear Team,</p>" +
                //              "<p>Embossing file not received on " + DateTime.Now.ToString("dd/MM/yyyy") + " .</p>" +
                //               "<p>Best regards,<br />" +
                //               "(Automated email, please do not reply.)</p>" +
                //               "</body>" +
                //               "</html>";
                //            DataEmail mail = new DataEmail();
                //            flg = mail.SendMail(fromMail, toadd, "", "sFTP File Not Received Acknowledgement", JobMailBody);
                //            if (flg)
                //            {
                //                flg = db.UpdateFilenotreceivedAcknowledgement(Convert.ToInt32(hostid), fileDate, filepathId);
                //                if (flg)
                //                {
                //                    sFTPFileCheckingService.WriteToFile("Perso file not Received Acknowledgement Mail send to Customer [" + customername + "] successfully...");
                //                }
                //                else
                //                {
                //                    sFTPFileCheckingService.WriteToFile("Perso file not Received Acknowledgement update [mailsendACK] failed for [" + customername + "] ...");
                //                }
                //            }
                //        }
                //    }
                //}
            }
            //else
            //{
            //    sFTPFileCheckingService.WriteToFile("truetime status : " + truetime);
            //}
        }
        // ************************ Acknowledgement to Customer End ************************
        #endregion

        private void RecursivelyFilechecking(string Filepath, string _todaydate, string hostid, bool isHeader, string hostName, Int32 CustomerId)
        {
            try
            {
                //sFTPFileCheckingService.WriteToFile("starting..." + Filepath);
                if (_sftp.Exists(Filepath))
                {
                    var files = _sftp.ListDirectory(Filepath);
                    //sFTPFileCheckingService.WriteToFile("after files shared...." + Filepath);
                    bool flg = false;
                    string JobMailBody;
                    string toadd = string.Empty;
                    string fileName = string.Empty;
                    string fileDate = string.Empty;
                    Int32 filepathId = 0;
                    string omittedDirectory = string.Empty;

                    omittedDirectory = db.GetOmittedDirectory(CustomerId);


                    string fromMail = ConfigurationManager.AppSettings["fromMail"].ToString();
                    //sFTPFileCheckingService.WriteToFile("before checking files");
                    //string _previousdate = DateTime.Now.AddDays(-1).ToString("ddMMyyyy");
                    foreach (var file in files)
                    {

                        if (file.IsDirectory && !file.Name.Equals(".") && !file.Name.Equals("..") && !file.Name.ToLower().Equals(omittedDirectory.ToLower()))
                        {
                            //flg = true;
                            //if (sftpData.Count > 0)
                            //{

                            //    sftpData.Clear();
                            //}
                            //sFTPFileCheckingService.WriteToFile("checking dic");
                            //sFTPFileCheckingService.WriteToFile(file.FullName + _todaydate + hostid + isHeader + hostName + CustomerId);
                            RecursivelyFilechecking(file.FullName, _todaydate, hostid, isHeader, hostName, CustomerId);
                        }
                        else if (!file.Name.Equals(".") && !file.Name.Equals("..") && !file.Name.ToLower().Equals(omittedDirectory.ToLower()))
                        {
                            //if (file.LastAccessTime.ToString("ddMMyyyy").Equals(_todaydate) || file.LastWriteTime.ToString("ddMMyyyy").Equals(_todaydate))
                            if (file.LastWriteTime.ToString("ddMMyyyy").Equals(_todaydate))
                            {

                                //if (flg)
                                //{
                                //    //lstBxFiles.Items.Add("Header/" + file.FullName);
                                //    //sftpData.Add("CustomerName: ");
                                //    flg = false;
                                //}
                                //lstBxFiles.Items.Add(file.Name + " / " + _todaydate);

                                //sFTPFileCheckingService.WriteToFile("before checklogfile");
                                //sFTPFileCheckingService.WriteToFile(hostid + file.Name + file.LastWriteTime.ToString("dd/MM/yyyy hh:mm tt"));
                                flg = db.Checkinglogfile(hostid, file.Name, file.LastWriteTime.ToString("dd/MM/yyyy hh:mm tt"));
                                if (!flg)
                                {
                                    //sFTPFileCheckingService.WriteToFile("before savelog");
                                    flg = db.Savelog(hostid, file.Name, file.LastWriteTime.ToString("dd/MM/yyyy hh:mm tt"), CustomerId);
                                    if (flg)
                                    {
                                        //                                    if (isHeader)
                                        //                                    {
                                        //                                        mailBodytext += @"<tr style='background-color:DodgerBlue; border:2px; color:aliceblue; font-size:22px;'>
                                        //			        <td colspan='2'><strong>JobType</strong></td>
                                        //			        <td colspan='2'><strong>" + hostName + "</strong></td></tr>";

                                        //                                        mailBodytext += @"
                                        //                            <tr style='background-color:MediumSeaGreen; border:2px; color:aliceblue; font-size:16px;'>
                                        //			            <td colspan='2'><strong>Customer Name</strong></td>
                                        //			            <td colspan='2'><strong>" + CustomerName + "</strong></td></tr>";

                                        //                                    }

                                        //                                    mailBodytext += @" <tr style='border:none;'>
                                        //			                                          <td colspan='4'>" + file.Name + "</td></tr>";
                                        //                                    sFTPFileCheckingService.WriteToFile(mailBodytext);
                                        //sFTPFileCheckingService.WriteToFile("before getsftplogfile");
                                        DataTable dt = db.GetsFTPlogFiles(Convert.ToInt32(hostid), CustomerId);
                                        if (dt != null && dt.Rows.Count > 0)
                                        {
                                            for (int i = 0; i <= dt.Rows.Count - 1; i++)
                                            {
                                                if (i == 0)
                                                {
                                                    if (filepathId != Convert.ToInt32(dt.Rows[i]["Id"]))
                                                    {
                                                        filepathId = Convert.ToInt32(dt.Rows[i]["Id"]);

                                                        JobMailBody = @"<html>
        <body>
         <p  style='font-family:Calibri; font-size:18px;color:#0369AA;'>Dear Team,</p>
         <p  style='font-family:Calibri; font-size:17px;color:#0369AA;'>Below listed sFTP file information.</p>
         <table border='1' cellpadding='1' cellspacing='1' style='min-width:50%'>
	        <tbody>
                    <tr style='background-color:DodgerBlue; border:0px; color:aliceblue; font-family:Calibri; font-size:20px;'>
			        <td colspan='1'><center>JobType</center></td>
			        <td colspan='1'><center>Customer Name<center></td> 
					<td colspan='1'><center>Message</center></td> 
					</tr>
                    <tr style='border:0px; font-family:Calibri; font-size:18px;'>
			        <td colspan='1'>" + dt.Rows[i]["hostname"].ToString() + "</td>" +
                                 "<td colspan='1'>" + dt.Rows[i]["customername"].ToString() + "</td>" +
                                                            //"<td colspan='1' style='text-align:center;'>" + Rcount + "</td></tr>" +
                                 "<td colspan='1' style='text-align:center;'> Perso file received on " + dt.Rows[i]["fileDate"].ToString() + "</td></tr>" +
                                 "</tbody>" +
                                 "</table>" +
                                 "<p style='font-family:Calibri; color:#0369AA;'>Best regards,<br />" +
                                 "(Automated email, please do not reply.)</p>" +
                             "</body>" +
                             "</html>";
                                                        DataTable dtmail = db.GetEmailIds(filepathId);
                                                        if (dtmail != null && dtmail.Rows.Count > 0)
                                                        {

                                                            foreach (DataRow rw in dtmail.Rows)
                                                                toadd += rw["Emailgrp"].ToString();
                                                            toadd = toadd.Substring(0, toadd.Length);
                                                        }

                                                        //WriteToFile("Email Id :" + toadd);

                                                        DataEmail mail = new DataEmail();
                                                        flg = mail.SendMail(fromMail, toadd, "", "sFTP File Received Notification", JobMailBody);
                                                    }
                                                    if (flg)
                                                    {
                                                        //for (int j = 0; j <= dt.Rows.Count - 1; j++)
                                                        //{
                                                        //  if (filepathId == Convert.ToInt32(dt.Rows[j]["Id"]))
                                                        // {

                                                        JobMailBody = string.Empty;
                                                        //hostid = dt.Rows[i]["hostid"].ToString();
                                                        //CustomerId = Convert.ToInt32(dt.Rows[i]["CustomerId"]);
                                                        fileName = dt.Rows[i]["filename"].ToString();
                                                        fileDate = dt.Rows[i]["fileDate"].ToString();
                                                        //WriteToFile("HostId: " + hostid.ToString() + " customerId : " + CustomerId + " filename: " + fileName + " filedate: " + fileDate);
                                                        //sFTPFileCheckingService.WriteToFile("before emilack");
                                                        flg = db.EmailAcknowledge(Convert.ToInt32(hostid), fileName, fileDate, CustomerId);
                                                        //}
                                                        //}
                                                        if (flg)
                                                        {

                                                            sFTPFileCheckingService.WriteToFile("Perso file [" + fileName + "] Received from [" + dt.Rows[i]["customername"].ToString() + "] on " + dt.Rows[i]["fileDate"].ToString() + " and Internal Group Mail send successfully...");
                                                            flg = false;
                                                        }

                                                    }


                                                    //else
                                                    //{
                                                    //    sFTPFileCheckingService.WriteToFile("Mail Failed.....");
                                                    //}

                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    sFTPFileCheckingService.WriteToFile("[Error] sFTP Path Does not Exist [sFTP Path : " + Filepath + "] on " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt"));
                }
            }
            catch (Exception ex)
            {
                //sFTPFileCheckingService.WriteToFile("error");
                sFTPFileCheckingService.WriteToFile("[Error] Error in sftp connection [Error Message : " + ex.Message + "] on " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt"));
            }
        }
    }
}
