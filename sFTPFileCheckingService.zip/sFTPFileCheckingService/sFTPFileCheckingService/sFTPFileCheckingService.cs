﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Threading;
namespace sFTPFileCheckingService
{
    public partial class sFTPFileCheckingService : ServiceBase
    {
        sFTPConnection sftp = new sFTPConnection();
        public static string JobMailBody;
        DBClass db = new DBClass();
        string todaydate = string.Empty;

        public sFTPFileCheckingService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            WriteToFile("sFTPFileCheckingService Service Started {0}");
            this.ScheduleService1();
            //WriteToFile("sFTPFileCheckingService  Evening Service Started {0}");
            //this.ScheduleService2();
        }

        protected override void OnStop()
        {
            WriteToFile("sFTPFileCheckingService Service Stopped {0}");
            this.ScheduleService1();
            //WriteToFile("sFTPFileCheckingService  Evening Service Stopped {0}");
            //this.ScheduleService2();
        }

        private Timer Schedular1;
        private Timer Schedular2;

        public void ScheduleService1()
        {
            try
            {

                Schedular1 = new Timer(new TimerCallback(SchedularCallback1));
                string mode = ConfigurationManager.AppSettings["Mode"].ToUpper();


                WriteToFile("sFTPFileCheckingService Service Mode: [" + mode + "] {0}");

                DateTime scheduledTime = DateTime.MinValue;

                if (mode == "DAILY")
                {

                    scheduledTime = DateTime.Parse(ConfigurationManager.AppSettings["ScheduledTime1"]);

                    if (DateTime.Now > scheduledTime)
                    {
                        scheduledTime = scheduledTime.AddDays(1);
                    }

                }

                if (mode.ToUpper() == "INTERVAL")
                {

                    int intervalMinutes = Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]);

                    scheduledTime = DateTime.Now.AddMinutes(intervalMinutes);

                    if (DateTime.Now > scheduledTime)
                    {
                        scheduledTime = scheduledTime.AddMinutes(intervalMinutes);
                    }

                    WriteToFile("sFTPFileCheckingService scheduled Mode[" + mode + "] Next : " + scheduledTime.ToString("dd-MMM-yyyy hh:mm:ss tt"));
                }

                TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);
                string schedule = string.Format("{0} day(s) {1} hour(s) {2} minute(s) {3} seconds ", timeSpan.Days, timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                WriteToFile("sFTPFileCheckingService scheduled to run after: " + schedule + "{0}");

                int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);
                Schedular1.Change(dueTime, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                WriteToFile("[Error] sFTPFileCheckingServie Error on: {0} " + ex.Message + ex.StackTrace + "on "+ DateTime .Now .ToString ("dd/MMM/yyyy hh:mm:ss tt"));
                using (System.ServiceProcess.ServiceController serviceController = new ServiceController("sFTPFileServices"))
                {
                    serviceController.Stop();
                }
            }
        }

        public void ScheduleService2()
        {
            try
            {
                Schedular2 = new Timer(new TimerCallback(SchedularCallback2));
                string mode = ConfigurationManager.AppSettings["Mode"].ToUpper();
                WriteToFile("sFTPFileCheckingService Service Mode: [" + mode + "] {0}");

                DateTime scheduledTime = DateTime.MinValue;

                if (mode == "DAILY")
                {
                    scheduledTime = DateTime.Parse(ConfigurationManager.AppSettings["ScheduledTime2"]);

                    if (DateTime.Now > scheduledTime)
                    {
                        scheduledTime = scheduledTime.AddDays(1);
                    }

                }

                if (mode.ToUpper() == "INTERVAL")
                {

                    int intervalMinutes = Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]);

                    scheduledTime = DateTime.Now.AddMinutes(intervalMinutes);

                    if (DateTime.Now > scheduledTime)
                    {
                        scheduledTime = scheduledTime.AddMinutes(intervalMinutes);
                    }
                }

                TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);
                string schedule = string.Format("{0} day(s) {1} hour(s) {2} minute(s) {3} seconds", timeSpan.Days, timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);
                WriteToFile("sFTPFileCheckingService scheduled to run after: " + schedule + "{0}");

                int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);
                Schedular2.Change(dueTime, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                WriteToFile("[Error] sFTPFileCheckingServie Error on: {0} " + ex.Message + ex.StackTrace + "on "+ DateTime.Now .ToString ("dd/MMM/yyyy hh:mm:ss tt"));
                using (System.ServiceProcess.ServiceController serviceController = new ServiceController("sFTPFileServices"))
                {
                    serviceController.Stop();
                }
            }

        }

        private void SchedularCallback1(object e)
        {
            try
            {
                WriteToFile("sFTPFileCheckingService Service Log: {0}");

                //db.DataPurge(DateTime.Now.AddDays(-7).ToString("dd/MM/yyyy"));

                sFTPMailService();
                Datapurge();
                this.ScheduleService1();
            }
            catch (Exception ex)
            {
                WriteToFile("Schedularcallback Error: " + ex.Message);
            }
        }

        private void SchedularCallback2(object e)
        {
            try
            {
                WriteToFile("sFTPFileCheckingService Service Log: {0}");
                //db.DataPurge(DateTime.Now.AddDays(-7).ToString("dd/MM/yyyy"));
                sFTPMailService();
                this.ScheduleService2();
            }
            catch (Exception ex)
            {
                WriteToFile("Schedularcallback Error: " + ex.Message);
            }
        }

        private void Datapurge()
        {
            if (todaydate != DateTime.Now.ToString("dd/MM/yyyy"))
            {
                todaydate = DateTime.Now.ToString("dd/MM/yyyy");
                db.DataPurge(DateTime.Now.AddDays(-8).ToString("dd/MM/yyyy"));
                //WriteToFile("sFTPFileCheckingServie Data purge date before change : " + todaydate);
            }
            //else
            //{
            //    WriteToFile("sFTPFileCheckingServie Data purge date changed : " + todaydate);
            //}
        }

        private void sFTPMailService()
        {
            try
            {
                //                DataTable dt = new DataTable();

                sftp.sFTPList();
            }
            catch (Exception ex)
            {
                WriteToFile("sFTPMailService : " + ex.Message);
            }
        }

     

        public static void WriteToFile(string text)
        {
            string path = ConfigurationManager.AppSettings["LogLocation"].ToString();
            try
            {
                using (StreamWriter writer = new StreamWriter(path, true))
                {
                    writer.WriteLine(string.Format(text, DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss tt")));
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
