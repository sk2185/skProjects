﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Findnumbersfromlist.Controllers.Home
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        private static List<FileUploadModel> uploadedFiles = new List<FileUploadModel>();
        private static FileUploadModel fileupload = new FileUploadModel();

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Upload()
        {
            //return View(uploadedFiles);
            return View(fileupload);
        }

        [HttpPost]
        public ActionResult UploadFile(HttpPostedFileBase file)
        {
            if (file != null && file.ContentLength > 0)
            {
                string uploadPath = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(uploadPath))
                    Directory.CreateDirectory(uploadPath);

                string filePath = Path.Combine(uploadPath, file.FileName);
                file.SaveAs(filePath);
                string userinput = Request.Form["Name"];
                ViewBag.Name = userinput;
                uploadedFiles.Add(new FileUploadModel { FileName = file.FileName, FilePath = filePath });

                fileupload.FileName = file.FileName;
                fileupload.FilePath = filePath;
                fileupload.Name = userinput;

                TempData["FileName"] = file.FileName;
                List<string> lstdata = System.IO.File.ReadAllLines(filePath).ToList();

                fileupload.lstfindData = lstdata.Where(f => f.Contains(userinput)).ToList();

                //string pattern = @"(\d)\1\1"; // with zeros
                string pattern = @"([1-9])\1\1"; // without zeros
                fileupload.lstfindrepeatednum = lstdata.Where(f => Regex.IsMatch(f, pattern)).ToList();

                
            }

            return RedirectToAction("Upload");
        }

       

    }
}
