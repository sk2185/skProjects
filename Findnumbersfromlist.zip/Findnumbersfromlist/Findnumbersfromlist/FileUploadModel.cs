﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Findnumbersfromlist
{
    public class FileUploadModel
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string Name { get; set; }
        public List<string> lstfindData { get; set; }
        public List<string> lstfindrepeatednum { get; set; }
    }
}